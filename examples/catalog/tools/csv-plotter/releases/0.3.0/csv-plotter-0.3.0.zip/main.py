placeholder for csv-plotter 0.3.0
