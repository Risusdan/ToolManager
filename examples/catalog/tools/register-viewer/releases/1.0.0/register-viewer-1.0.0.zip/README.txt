register-viewer 1.0.0 demo package
