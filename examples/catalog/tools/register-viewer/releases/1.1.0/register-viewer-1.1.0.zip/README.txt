register-viewer 1.1.0 demo package
